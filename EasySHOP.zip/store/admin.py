from django.contrib import admin
from .models.products import Product
from .models.category import Category
from .models.customer import Customer
from .models.orders import Order


# Register your models here.

class AdminProduct(admin.ModelAdmin):
    list_display = ['Brand_name', 'color', 'price', 'category', 'size', 'image']


class AdminCategory(admin.ModelAdmin):
    list_display = ['category']


admin.site.register(Product, AdminProduct)
admin.site.register(Category, AdminCategory)
admin.site.register(Customer)
admin.site.register(Order)
